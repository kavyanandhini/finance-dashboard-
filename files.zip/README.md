# FinFlow — Finance Dashboard

A clean, interactive personal finance dashboard built as a single-file HTML application.
Submitted as part of the Frontend Developer Intern assessment for Zorvyn.

---

## Live Preview

Open `index.html` directly in any modern browser — no build step, no server required.

---

## Features

### Dashboard Overview
- **4 Summary Cards** — Total Balance, Total Income, Total Expenses, This Month's Spend
- **Balance Trend Chart** — Grouped bar chart showing 6 months of income vs expenses
- **Spending Donut Chart** — Category-wise breakdown with percentage legend
- **Recent Transactions** — Quick-glance list of the 5 most recent entries

### Transactions Section
- Full sortable, filterable transaction table
- **Search** by description or category keyword
- **Filter** by Category, Type (Income/Expense), and Month
- **Sort** by Date or Amount (ascending/descending toggle)
- Clear all filters in one click

### Role-Based UI
- **Admin** — can Add, Edit, and Delete transactions; all controls visible
- **Viewer** — read-only mode; add/edit/delete buttons hidden
- Toggle between roles using the pill buttons in the top bar

### Insights Section
- **Top Spending Category** with total amount
- **Savings Rate** with visual progress bar and contextual label
- **Average Monthly Expense** across all recorded months
- **Biggest Transaction** recorded
- **Monthly Comparison Table** — Income, Expenses, Net, and Savings Rate per month
- **Category Spending Trend** — Multi-line chart showing per-category spend over time

### Optional Enhancements Implemented
- **Dark / Light Mode** — toggle via sun/moon button; persists via CSS variables
- **Data Persistence** — transactions saved to `localStorage`; survive page reload
- **Export CSV** and **Export JSON** — download your transaction data
- **Responsive Design** — adapts from mobile (320px) to desktop (1440px+)
- **Animations** — staggered fade-in on load, hover lifts on cards
- Graceful **empty state** when no transactions match filters

---

## Setup

No dependencies, no npm install needed.

```bash
# Just open the file
open index.html          # macOS
start index.html         # Windows
xdg-open index.html      # Linux
```

Or drag `index.html` into any browser window.

---

## Project Structure

```
finance-dashboard/
└── index.html    # Complete app — HTML + CSS + JS in one file
```

All logic, styles, and markup live in a single self-contained file for easy review and portability. Chart.js is loaded via CDN (cdnjs.cloudflare.com).

---

## Technical Approach

### State Management
All application state is held in plain JavaScript variables:
- `transactions[]` — source of truth for all financial data
- `currentRole` — drives admin/viewer UI differences
- `isDark` — controls theme
- `sortField` / `sortDir` — drives table sort state

State is persisted to `localStorage` on every write. On load, saved data is restored or seed data is used.

### Component Architecture
Although this is a single-file app, the code is structured into clear logical sections:
- **Data layer** — load/save, seed data, formatting helpers
- **Stats layer** — pure functions that derive summaries from transaction array
- **Render layer** — one function per UI section (`renderSummary`, `renderTrendChart`, etc.)
- **Event handlers** — modal open/close, role switch, theme toggle, exports

### Design Decisions
- **CSS custom properties** power the entire theme system — swapping dark/light changes one attribute on `<html>`
- Charts are destroyed and recreated on data change to avoid Chart.js stale reference issues
- Filters are applied client-side on every keystroke / select change for instant feedback
- `localStorage` is wrapped in try/catch to handle private browsing gracefully

---

## Sample Data

The app ships with 55 seed transactions spanning October 2025 – March 2026, covering realistic Indian expense categories (Salary, Rent, Food & Dining, Transport, Shopping, etc.) with amounts in INR.

---

## Browser Support

Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

---

## Author

Kavya — Frontend Developer Intern Candidate, Zorvyn Assessment 2026
